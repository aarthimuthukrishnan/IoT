<?php 
	$conn = mysqli_connect("localhost","id787294_root","9985037848","id787294_aarthi");

/* check connection */
	if (mysqli_connect_errno()) {
		printf("Connect failed: %s\n", mysqli_connect_error());
		exit();
	}
	$error=false;
	if (isset($_POST['email'])){
	  $email = trim($_POST['email']);
	  $email = strip_tags($email);
	  $email = htmlspecialchars($email);
	}
	else{
		$error = true;
		$emailError='Please enter name';
	}
	if (isset($_POST['password'])){
	  $password = trim($_POST['password']);
	  $password = strip_tags($password);
	  $password = htmlspecialchars($password);
	}
	else{
		$error = true;
		$passError='Please enter name';
	}
	if ( !filter_var($email,FILTER_VALIDATE_EMAIL) ) {
		$error = true;
		$emailError = "Please enter valid email address.";
	}
	if (empty($password)){
		$error = true;
		$passError = "Please enter password.";
	} else if(strlen($password) < 6) {
		$error = true;
		$passError = "Password must have atleast 6 characters.";
	}
	if(!$error){
		$email = mysqli_real_escape_string($conn,$email);
		$password = mysqli_real_escape_string($conn,$password);
		$sel_user=mysqli_query($conn,"SELECT * FROM Users where Email='$email' and Password='$password'");
		$check_user = mysqli_num_rows($sel_user);
		if($check_user == 1){
session_start();
$_SESSION['Email']=$email;
$sel_user=mysqli_query($conn,"Update Users set Flag=0");
$sel_user=mysqli_query($conn,"Update Users set Flag=1 where Email='$email' and Password='$password'");
$sel_user=mysqli_query($conn,"Select Message From Retmes where Email='$email' and Notified=0");
$row = mysqli_fetch_assoc($sel_user);
$sel_user=mysqli_query($conn,"Update Retmes set Notified=1 where Email='$email'");
			echo $row['Message'];
		}else {
			echo "fail";
		}
	}
?>