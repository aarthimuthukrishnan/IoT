<?php 
	$conn = mysqli_connect("localhost","id787294_root","9985037848","id787294_aarthi");

/* check connection */
	if (mysqli_connect_errno()) {
		printf("Connect failed: %s\n", mysqli_connect_error());
		exit();
	}
	$error=false;
	if (isset($_POST['email'])){
	  $email = trim($_POST['email']);
	  $email = strip_tags($email);
	  $email = htmlspecialchars($email);
	}
	else{
		$error = true;
		$emailError='Please enter name';
	}
	
	if(!$error){
		$email = mysqli_real_escape_string($conn,$email);
		session_start();
		$_SESSION['Email']=$email;
		$sel_user=mysqli_query($conn,"Select Message From Retmes where Email='$email' and Notified=1");
		$row = mysqli_fetch_assoc($sel_user);
		$sel_user=mysqli_query($conn,"Update Retmes set Notified=1 where Email='$email'");
		echo $row['Message'];
	}
?>