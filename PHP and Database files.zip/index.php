<html>
 <head>
<style>
body{font-family:Calibri, Candara, Segoe, "Segoe UI", Optima, Arial, sans-serif;}
button{ padding:7px 20px;line-height:126%;border:1px solid #69a74e;border-radius:10px; background:#00ADEE; color:white; font-weight:bold; font-size:20px; border-color:#3b6e22 #3b6e22 #2c5115}
</style>
  <meta http-equiv="refresh" content="1; url=<?php echo $_SERVER['PHP_SELF']; ?>">
 </head>
<?php 
session_start();

	$conn = mysqli_connect("localhost","id787294_root","9985037848","id787294_aarthi");
	if (mysqli_connect_errno()) {
		printf("Connect failed: %s\n", mysqli_connect_error());
		exit();
	}
        $sel_user=mysqli_query($conn,"SELECT Name, Email, Flag FROM Users");
       $row = mysqli_fetch_array($sel_user, MYSQLI_NUM);
$_SESSION['Email']=$row[1];
if($row[2]==1){
       echo "<div style=\"width: 50%;display: table-cell;text-align: center; height: 50%;position:absolute;vertical-align: middle;right:0;left:0;top:0;bottom:0;margin:auto;\"><b style=\"font-size:50px;color:rgba(0,0,0,1)\">".$row[0]."</b>"."<br><i style=\"font-size:50px;color:rgba(0,0,0,0.8);\"> Please meet receptionist</i><br><a href=\"return_message.php\"><button>Send a return message</button></a></div>";
}else{
echo "<div style=\"width: 50%;display: table-cell;text-align: center; height: 50%;position:absolute;vertical-align: middle;right:0;left:0;top:0;bottom:0;margin:auto;\"><b style=\"font-size:50px;color:rgba(0,0,0,1)\">".$row[0]."</b>"."<br><i style=\"font-size:50px;color:rgba(0,0,0,0.8);\"> Welcomes you to Stelar</i><br></div>";
}
?>