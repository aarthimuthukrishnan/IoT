<?php 
	$conn = mysqli_connect("localhost","id787294_root","9985037848","id787294_aarthi");

/* check connection */
	if (mysqli_connect_errno()) {
		printf("Connect failed: %s\n", mysqli_connect_error());
		exit();
	}
	$error=false;
	if (isset($_POST['email'])){
	  $email = trim($_POST['email']);
	  $email = strip_tags($email);
	  $email = htmlspecialchars($email);
	}
	else{
		$error = true;
		$emailError='Please enter name';
	}
	if (isset($_POST['message'])){
	  $message = trim($_POST['message']);
	  $message = strip_tags($message);
	  $message = htmlspecialchars($message);
	}
	else{
		$error = true;
		$passError='Please enter name';
	}
	if ( !filter_var($email,FILTER_VALIDATE_EMAIL) ) {
		$error = true;
		$emailError = "Please enter valid email address.";
	}
	
	if(!$error){
		$email = mysqli_real_escape_string($conn,$email);
		$message = mysqli_real_escape_string($conn,$message);
		$sel_user=mysqli_query($conn,"Update Messages set Message='$message' where Email='$email'");
		if($sel_user){
			echo "success";
		}else {
			echo $sel_user;
		}
	}
	
?>