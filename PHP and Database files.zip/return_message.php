<html>
 <head>
<style>
body{font-family:Calibri, Candara, Segoe, "Segoe UI", Optima, Arial, sans-serif;}
#button{ padding:7px 20px;line-height:126%;border:1px solid #69a74e;border-radius:10px; background:#00ADEE; color:white; font-weight:bold; font-size:20px; border-color:#3b6e22 #3b6e22 #2c5115}
</style>
<?php
$error=false;
session_start();
if (isset($_POST["submit"])) {
	$Email=$_SESSION['Email'];
    if (isset($_POST['pass'])){
	  $pass = trim($_POST['pass']);
	  $pass = strip_tags($pass);
	  $pass = htmlspecialchars($pass);
	}
	else{
		$error = true;
		$passError='Please enter Password';
	}
    if (isset($_POST['message'])){
	  $message= trim($_POST['message']);
	  $message= strip_tags($message);
	  $message= htmlspecialchars($message);
	}
	else{
		$error = true;
		$nameError='Please enter name';
	}
	$conn = mysqli_connect("localhost","id787294_root","9985037848","id787294_aarthi");
	if (mysqli_connect_errno()) {
		printf("Connect failed: %s\n", mysqli_connect_error());
		exit();
	}
	$message= mysqli_real_escape_string($conn,$message);
	$pass = mysqli_real_escape_string($conn,$pass);
	if($pass == "StelaR"){
		$sel_user=mysqli_query($conn,"Update Retmes set Message='$message', Notified=0 where Email='$Email'");
		if($sel_user){
						  echo "<script>alert('Message sent');window.location.href='index.php';</script>";
					}
	}else {
		echo "Invalid Password";
	} 
}else{
?>
<body>
<div style="width: 50%;display: table-cell;text-align: center; height: 50%;position:absolute;vertical-align: middle;right:0;left:0;top:0;bottom:0;margin:auto;">
<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
Password<br><input type="password" name="pass" placeholder="Admin Password"><br><br>
Message<br>
<TEXTAREA NAME="message" COLS=40 ROWS=6></TEXTAREA><br><br>
<input type="submit" name="submit" id="button" value="Submit">
</form>
<?php 

        
	} 
?>